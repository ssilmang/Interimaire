<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Service extends Model
{
    use HasFactory;

    protected $fillable = ['libelle', 'chef_de_service_id'];

    public function chefDeService()
    {
        return $this->belongsTo(ChefDeService::class);
    }

    public function responsables()
    {
        return $this->hasMany(Responsable::class);
    }
}
