<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ChefDeService extends Model
{
    use HasFactory;

    protected $table = 'chef_de_services';

    protected $fillable = ['libelle', 'departement_id'];

    public function departement()
    {
        return $this->belongsTo(Departement::class);
    }

    public function responsables()
    {
        return $this->hasMany(Responsable::class);
    }

    public function services()
    {
        return $this->hasMany(Service::class);
    }
}
