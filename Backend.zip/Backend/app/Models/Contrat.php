<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Contrat extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'poste_id',
        'responsable_id',
        'agence_id',
        'categorie_id',
        'date_debut_contrat',
        'cumul_temps_presence',
        'date_fin_contrat',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function poste()
    {
        return $this->belongsTo(Poste::class);
    }

    public function responsable()
    {
        return $this->belongsTo(Responsable::class);
    }

    public function agence()
    {
        return $this->belongsTo(Agence::class);
    }

    public function categorie()
    {
        return $this->belongsTo(Categorie::class);
    }
    
}
