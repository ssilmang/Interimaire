<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Departement extends Model
{
    use HasFactory;

    protected $fillable = ['libelle', 'locau_id'];

    public function locaus()
    {
        return $this->belongsTo(Locau::class, 'locau_id');
    }

    public function ChefDeService()
{
    return $this->hasMany(ChefDeService::class);
}
}
