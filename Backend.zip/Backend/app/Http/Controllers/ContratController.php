<?php

namespace App\Http\Controllers;

use App\Http\Resources\ContratResource;
use App\Models\Contrat;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class ContratController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        try {
        // Récupérer tous les contrats avec les informations associées
        $contrats = Contrat::with(['user', 'poste', 'responsable', 'agence', 'categorie'])->get();



        // Retourner les contrats formatés sous forme de réponse JSON
        return response()->json([
            'statut' => 200,
            'message'=>"dff",
            'data' =>[
                'Interim'=>ContratResource::collection($contrats)
            ]
        ]);
    } catch (\Exception $e) {
        // Gérer les erreurs éventuelles
        return response()->json([
            'status' => 500,
            'message' => 'Une erreur est survenue lors de la récupération des contrats.',
            'error' => $e->getMessage(),
        ], 500);
    }
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        try {
        $request->validate([
            'nom' => 'required|string',
            'prenom' => 'required|string',
            'email' => 'required|email|unique:users,email',
            'password' => 'required|string',
            'telephone' => ['required', 'string', 'regex:/^(70|77|76|75|78)\d{7}$/', 'unique:users,telephone'],
            'poste_id' => 'required|exists:postes,id',
            'responsable_id' => 'nullable|exists:responsables,id',
            'agence_id' => 'nullable|exists:agences,id',
            'categorie_id' => 'nullable|exists:categories,id',
            'date_debut_contrat' => 'required|date',
            'cumul_temps_presence' => 'required|integer',
        ]);

        // Génération du matricule unique
        // $matricule = 'M' . strtoupper(substr($request->nom, 0, 3)) . strtoupper(substr($request->prenom, 0, 3)) . '-' . uniqid();

        // Créer un nouvel utilisateur sans inclure le champ 'role_id'
        $user = User::create([
            'nom' => $request->nom,
            'prenom' => $request->prenom,
            'email' => $request->email,
            'password' => Hash::make($request->password),
            'telephone' => $request->telephone,
            'matricule' => $request->matricule,
        ]);

        // Calculer la date de fin du contrat (2 ans à partir de la date de début)
        $dateDebut = Carbon::parse($request->date_debut_contrat);
        $dateFinContrat = $dateDebut->copy()->addYears(2);

        // Créer un nouveau contrat en utilisant l'ID de l'utilisateur et les autres informations
        $contrat = Contrat::create([
            'user_id' => $user->id,
            'poste_id' => $request->poste_id,
            'responsable_id' => $request->responsable_id,
            'agence_id' => $request->agence_id,
            'categorie_id' => $request->categorie_id,
            'date_debut_contrat' => $request->date_debut_contrat,
            'cumul_temps_presence' => $request->cumul_temps_presence,
            'date_fin_contrat' => $dateFinContrat,
        ]);

        return response()->json([
            'status' => 'success',
            'message' => 'Contrat created successfully.',
            'data' => $contrat,
        ], 201);
    } catch (\Exception $e) {
        return response()->json([
            'status' => 'error',
            'message' => 'Failed to create contrat.',
            'error' => $e->getMessage(),
        ], 500);
    }
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
