<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\ChefDeService;
use Illuminate\Database\QueryException;
use Illuminate\Validation\ValidationException;

class ChefDeServiceController extends Controller
{

    public function index()
    {
        try {
            // Récupérer tous les chefs de service avec leurs départements
            $chefsDeService = ChefDeService::with('departement')->get();

            // Retourner les chefs de service sous forme de réponse JSON avec le libellé du département
            return response()->json([
                'status' => 200,
                'data' => $chefsDeService->map(function ($chef) {
                    return [
                        'id' => $chef->id,
                        'libelle' => $chef->libelle,
                        'departement' => ['id'=>$chef->departement ? $chef->departement->id : null,
                                        'libelle'=>$chef->departement ? $chef->departement->libelle : null],
                    ];
                }),
            ]);
        } catch (\Exception $e) {
            // Gérer les erreurs éventuelles
            return response()->json([
                'status' => 500,
                'message' => 'Une erreur est survenue lors de la récupération des chefs de service.',
            ], 500);
        }
    }

    public function store(Request $request)
    {
        try {
                $request->validate([
                    'libelle' => 'required|string',
                    'departement_id' => 'required|exists:departements,id',
                ]);

                $chefDeService = ChefDeService::create([
                    'libelle' => $request->libelle,
                    'departement_id' => $request->departement_id,
                ]);

                return response()->json([
                    "status" => 200,
                    "message" => "Chef de service ajouté avec succès",
                    "data" => $chefDeService,
                ]);
            } catch (ValidationException $e) {
                return response()->json([
                    "status" => 400,
                    "message" => "Erreur de validation",
                    "errors" => $e->errors(),
                ], 400);
            } catch (QueryException $e) {
                return response()->json([
                    "status" => 500,
                    "message" => "Erreur lors de l'ajout du chef de service",
                    "error" => $e->getMessage(),
                ], 500);
        }
    }
}
