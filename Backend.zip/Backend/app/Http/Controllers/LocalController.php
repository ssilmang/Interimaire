<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Locau;

class LocalController extends Controller
{
    public function store(Request $request)
    {
        $request->validate([
            'libelle' => 'required|string',
            'adresse' => 'required|string',
        ]);

        $local = Locau::create([
            'libelle' => $request->libelle,
            'adresse' => $request->adresse,
        ]);

        return response()->json([
            "status" => 200,
            "message" => "Lieu d'execution ajouté avec succès",
            "data" => $local,
        ]);
    }
}
