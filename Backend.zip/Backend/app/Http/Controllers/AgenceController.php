<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Agence;

class AgenceController extends Controller
{
    public function store(Request $request)
    {
        $request->validate([
            'libelle' => 'required|string|max:255',
        ]);

        $agence = Agence::create([
            'libelle' => $request->libelle,
        ]);
        return response()->json(['message' => 'L\'Agence a été ajouté avec succès', 'agence' => $agence], 200);
    }
}
