<?php

namespace App\Http\Controllers;

use App\Models\Categorie;
use Illuminate\Http\Request;

class CategorieController extends Controller
{
    public function store(Request $request)
    {
        $request->validate([
            'libelle' => 'required|string|max:255',
        ]);

        $categorie = Categorie::create([
            'libelle' => $request->libelle,
        ]);

        return response()->json(['message' => 'Le categorie a été ajouté avec succès', 'categorie' => $categorie], 200);
    }
}
