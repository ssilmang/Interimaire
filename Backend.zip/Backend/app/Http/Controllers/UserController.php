<?php

namespace App\Http\Controllers;

use App\Http\Resources\ResponsableResource;
use App\Models\Service;
use App\Models\ChefDeService;
use App\Models\Departement;
use App\Models\Locau;
use App\Models\Responsable;
use App\Models\Role;
use Illuminate\Support\Facades\DB;
use Illuminate\Database\QueryException;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class UserController extends Controller
{
    public function store(Request $request)
{
    try{
        return DB::transaction(function() use($request){
            $request->validate([
                'nom' => 'required|string',
                'prenom' => 'required|string',
                'email' => 'required|email|unique:users,email',
                'password' => 'required|string',
                'matricule' => 'required|string|unique:users,matricule',
                'role_id' => 'required|exists:roles,id',
                'telephone' => ['required', 'string', 'regex:/^(70|77|76|75|78)\d{7}$/', 'unique:users,telephone'],
            ]);

            $username = Str::slug($request->nom . '_' . $request->matricule, '_');

            $user = User::create([
                'nom' => $request->nom,
                'prenom' => $request->prenom,
                'email' => $request->email,
                'password' => Hash::make($request->password),
                'matricule' => $request->matricule,
                'username' => $username,
                'role_id' => $request->role_id,
                'telephone' => $request->telephone,
            ]);

            // Vérifier si le rôle correspond à un responsable
            $role = Role::findOrFail($request->role_id);
            if ($role->libelle === "Responsable") {
                $request->validate([
                    'locau_id' => 'required|exists:locaus,id',
                    'departement_id' => 'required|exists:departements,id',
                    'chef_de_service_id' => 'required|exists:chef_de_services,id',
                    'service_id' => 'required|exists:services,id',
                ]);

                // Vérifier les relations entre les entités
                $local = Locau::findOrFail($request->locau_id);
                $departement = Departement::findOrFail($request->departement_id);
                $chef_de_service = ChefDeService::findOrFail($request->chef_de_service_id);
                $service = Service::findOrFail($request->service_id);

                // Vérifier les associations entre les entités
                if ($departement->locau_id !== $local->id) {
                    return response()->json([
                        "status" => 400,
                        "message" => "Le département sélectionné n'appartient pas au locaux spécifié."
                    ], 400);
                }

                if ($chef_de_service->departement_id !== $departement->id) {
                    return response()->json([
                        "status" => 400,
                        "message" => "Le chef de service sélectionné n'appartient pas au département spécifié."
                    ], 400);
                }

                if ($service->chef_de_service_id !== $chef_de_service->id) {
                    return response()->json([
                        "status" => 400,
                        "message" => "Le service sélectionné n'appartient pas au chef de service spécifié."
                    ], 400);
                }

                // Associer l'utilisateur aux entités
                // $user->local()->associate($local);
                // $user->departement()->associate($departement);
                // $user->ChefDeService()->associate($chef_de_service);
                // $user->service()->associate($service);

                $user->save();

                Responsable::create([
                    "user_id"=>$user->id,
                    "chef_de_service_id"=>$chef_de_service->id,
                    "service_id"=>$service->id,
                ]);
                return response()->json([
                            "status" => 200,
                            "message" => "Utilisateur ajouté avec succès",
                            "data" => $user,
                        ]);
            }
        });

        }catch(QueryException $e){
            return response()->json([
                "statut"=>221,
                "message"=>"erreur",
                "data"=>$e->getMessage(),
            ]);
        }
        }


        public function GuetResponsable()
        {
            $responsable = Responsable::all();
            return response()->json([
                "statut"=>Response::HTTP_OK,
                "message"=>"all",
                "data"=>ResponsableResource::collection($responsable)

            ]);
        }
}


