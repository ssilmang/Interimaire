<?php

namespace App\Http\Controllers;

use App\Models\Role;
use Illuminate\Http\Request;

class RoleController extends Controller
{
    public function store(Request $request)
    {
        $request->validate([
            'libelle' => 'required|string|max:255',
        ]);

        $role = Role::create([
            'libelle' => $request->libelle,
        ]);

        return response()->json(['message' => 'Le rôle a été ajouté avec succès', 'role' => $role], 201);
    }
}
